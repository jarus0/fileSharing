#!/bin/sh

# ============================
# Constants
# ============================
DEBUG_=0
IS_GPIO_INIT=0
FILES_DIR=/root/routine/
# ============================
# GPIO Pin CONSTANTS, mode: Broadcom
# ============================
GPIO_DIR=/root/gpio
GPIO_CTL=$GPIO_DIR/gpio_ctl.sh
source $GPIO_DIR/pin_def

GPIO_VPS=0
GPIO_USB_1=$O_USB1
	USB_1_BUS="1-1.3:1.0"
GPIO_USB_2=$O_USB2
	USB_2_BUS="1-1.1:1.0"
GPIO_USB_3=$O_USB3
	USB_3_BUS="1-1.4:1.0"
GPIO_USB_4=$O_USB4
	USB_4_BUS="1-1.2:1.0"
# ============================
# Routine definitions 
# ============================
#
set_gpio_init(){
	IS_GPIO_INIT=1
}

internet_routine(){
	# checks if sites are reachable
	echo -e "GET http://google.com HTTP/1.0\n\n" | nc google.com 80 > /dev/null 2>&1
	if [ $? -eq 0 ]; then
		[ $DEBUG_ -eq 1 ] && echo "[DEBUG] internet: online"
		$GPIO_CTL $O_NET out 1
		echo "1" > $FILES_DIR/internet_status
	else
		[ $DEBUG_ -eq 1 ] && echo "[DEBUG] internet: offline"
		echo "0" > $FILES_DIR/internet_status
		$GPIO_CTL $O_NET out 0
	fi
}

wifi_ap_routine(){
	# check if wifi hotspot (AP) is enabled
	if [ $(cat /sys/class/net/wlan0/operstate) == "up" ]; then
		[ $DEBUG_ -eq 1 ] && echo "[DEBUG] wifi_ap: enabled"
		echo '1' > $FILES_DIR/wifi_status
		$GPIO_CTL $O_WIFI out 1
	else
		[ $DEBUG_ -eq 1 ] && echo "[DEBUG] wifi_ap: disabled restarting"
		sleep 5
		echo '0' > $FILES_DIR/wifi_status
		$GPIO_CTL $O_WIFI out 0
	fi
}

usb_routine(){
	# checks on which usb ports usb teathering is enabled
	# 
	BUS_LOC='/sys/bus/usb/devices'
	# Port 1
	# Test bus with ip
	if [ -f $BUS_LOC/$USB_1_BUS/net/usb*/address ]; then
		[ $DEBUG_ -eq 1 ] && echo "[DEBUG] USB PORT 1: online"
		$GPIO_CTL $GPIO_USB_1 out 1
	else
		[ $DEBUG_ -eq 1 ] && echo "[DEBUG] USB PORT 1: offline"
		$GPIO_CTL $GPIO_USB_1 out 0
	fi
	#
	# Port 2:
	# Test bus with ip
	if [ -f $BUS_LOC/$USB_2_BUS/net/usb*/address ]; then
		[ $DEBUG_ -eq 1 ] && echo "[DEBUG] USB PORT 2: online"	
		$GPIO_CTL $GPIO_USB_2 out 1
	else
		[ $DEBUG_ -eq 1 ] && echo "[DEBUG] USB PORT 2: offline"
		$GPIO_CTL $GPIO_USB_2 out 0
	fi
	# Port 3:
	# Test bus with ip
	if [ -f $BUS_LOC/$USB_3_BUS/net/usb*/address ]; then
		[ $DEBUG_ -eq 1 ] && echo "[DEBUG] USB PORT 3: online"
		$GPIO_CTL $GPIO_USB_3 out 1
	else
		[ $DEBUG_ -eq 1 ] && echo "[DEBUG] USB PORT 3: offline"
		$GPIO_CTL $GPIO_USB_3 out 0
	fi
	# Port 4:
	# Test bus with ip
	if [ -f $BUS_LOC/$USB_4_BUS/net/usb*/address ]; then
		[ $DEBUG_ -eq 1 ] && echo "[DEBUG] USB PORT 4: online"
		$GPIO_CTL $GPIO_USB_4 out 1
	else
		[ $DEBUG_ -eq 1 ] && echo "[DEBUG] USB PORT 4: offline"
		$GPIO_CTL $GPIO_USB_4 out 0
	fi	
}

vps_routine(){
	# Check if vps is reachable
	# get your vps setting
	if  [ $(uci get openmptcprouter.vps.admin_error) -eq 0 ]; then
		[ $DEBUG_ -eq 1 ] && echo "[DEBUG] VPS: enabled"
		echo '1' > $FILES_DIR/vps_status
		$GPIO_CTL $O_VPS out 1
	else
		[ $DEBUG_ -eq 1 ] && echo "[DEBUG] VPS: disabled"
		echo '0' > $FILES_DIR/vps_status
		$GPIO_CTL $O_VPS out 0
	fi
}
# ============================
# Execute
# ============================
while true;
do
#set_gpio_init
	internet_routine
	wifi_ap_routine
	usb_routine
	vps_routine
	sleep 5
done

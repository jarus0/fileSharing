#!/bin/sh

# Enable execution
chmod +x /root/routine/routines.sh

# Add to cronjob
echo "*/1 * * * * /root/routine/routines.sh" >> $CRON_FILE

# Prompt Installed
echo "[Complete] Routines Installing and adding to cron job, wifi, internet, vps, usb"

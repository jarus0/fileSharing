#!/bin/sh

FILES_DIR=/root/fs_check

# Copy the script
cp $FILES_DIR/bipolar_fsck /etc/init.d/
chmod +x /etc/init.d/bipolar_fsck

# enable the script
/etc/init.d/bipolar_fsck enable

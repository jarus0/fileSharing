#!/bin/sh

source /root/gpio/pin_def

echo $O_WIFI

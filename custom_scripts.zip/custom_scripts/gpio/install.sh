#!/bin/sh

# Enable execution
chmod +x /root/gpio/gpio_ctl.sh

# Prompt
echo "[Completed] GPIO: script enabled, interact with gpio using /root/gpio_ctl.sh"

#!/bin/sh

LOCAL_DIR=/root

# Make Executables
CRON_FILE=/var/spool/cron/crontabs/root
export CRON_FILE

# touch $CRON_FILE

chmod +x /root/gpio/install.sh
/bin/sh /root/gpio/install.sh

chmod +x /root/routine/install.sh
/bin/sh /root/routine/install.sh

# Updating Wifi Setting
# WIFI_DRIVER=$(uci get wireless.radio0.path)
# sed "s+paste-driver-here+'${WIFI_DRIVER}'+g" $LOCAL_DIR/wireless_setting.template > $LOCAL_DIR/wireless_setting
# cp $LOCAL_DIR/wireless_setting /root/config/wireless

# # Replace all configuration files
# rm -r /etc/config
# cp -r /root/config/ /etc/config/

# # Change vps settings
# DEFAULT_VPS_IP=52.66.246.79
# DEFAULT_VPS_KEY=1E65C3ED5C2C52EB4F57F88C7E162E924C5F6C71A3C1169128293B32CCF234CD
# chmod +x /root/set_vps_setting.sh
# /bin/sh /root/set_vps_setting.sh $DEFAULT_VPS_IP $DEFAULT_VPS_KEY

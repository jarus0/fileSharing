#!/bin/sh

FILES_DIR=/root/webdashboard/custom

TEMP_LOC=/www/luci-static/resources
cp $FILES_DIR/menu-openmptcprouter.js $TEMP_LOC
cp $FILES_DIR/menu-admin-openmptcprouter.js $TEMP_LOC

# css stylesheet copy
cp $FILES_DIR/cascade.css /www/luci-static/openmptcprouter/
cp $FILES_DIR/mobile.css /www/luci-static/openmptcprouter/

# copy logo
cp $FILES_DIR/omr-logo.png /www/luci-static/resources/openmptcprouter/images

# copy template html
TEMP_LOC=/usr/lib/lua/luci/view/themes/openmptcprouter
cp $FILES_DIR/footer.htm $TEMP_LOC
cp $FILES_DIR/header.htm $TEMP_LOC